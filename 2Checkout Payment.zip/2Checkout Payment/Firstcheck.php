<?php
//https://www.2checkout.com/checkout/purchase
https://sandbox.2checkout.com/checkout/purchase
?>
<?php 

?>
<form action='https://www.2checkout.com/checkout/purchase' method='post'>
Enter name of card_holder:<input type='' name='card_holder_name' value="" >  <!--Card holder name Bhej nai bala--></br>
Enter name of Product reciver:<input type='' name='ship_name' value="" >  <!--Card holder namerecive karnai nai bala--></br>
Enter email for recive product details and biill information:<input type='' name='email' value="" > <!--Email id which recive products details and bill information--></br>
<input type='hidden' name='sid' value='1303908' >
<input type='hidden' name='mode' value='2CO' >
<input type='hidden' name='li_0_type' value='product' >
Enter Product Name:<input type='text' name='li_0_name' value="" ></br>
Enter Product Id:<input type='text' name='li_0_product_id' value="" ></br>
<input type='hidden' name='li_0__description' value='Example Product Description' >
Enter Product Price:<input type='text' name='li_0_price' value="" ></br>
Enter Product Quantity:<input type='text' name='li_0_quantity' value="" ></br>
<input type='hidden' name='li_0_tangible' value='Y' >
<input type='hidden' name='li_1_type' value='shipping' >
<input type='hidden' name='li_1_name' value='Example Shipping Method' >
<input type='hidden' name='li_1_price' value='1.50' >
<input type='hidden' name='li_2_type' value='coupon' >
<input type='hidden' name='li_2_name' value='Example Coupon' >
<input type='hidden' name='li_2_price' value='1.00' >
<input type='hidden' name='li_3_type' value='tax' >
<input type='hidden' name='li_3_name' value='Example Tax' >
<input type='hidden' name='li_3_price' value='0.50' >

<input type='hidden' name='street_address' value='123 Test St' >
<input type='hidden' name='street_address2' value='Suite 200' >
<input type='hidden' name='city' value='Columbus' >
<input type='hidden' name='state' value='OH' >
<input type='hidden' name='zip' value='43228' >
<input type='hidden' name='country' value='USA' ></br>

<input type='hidden' name='phone' value='614-921-2450' >
<input type='hidden' name='phone_extension' value='197' ></br>

<input type='hidden' name='ship_street_address' value='1234 Address Road' >
<input type='hidden' name='ship_street_address2' value='Apartment 123' >
<input type='hidden' name='ship_city' value='Columbus' >
<input type='hidden' name='ship_state' value='OH' >
<input type='hidden' name='ship_zip' value='43235' >
<input type='hidden' name='ship_country' value='USA' >
<input name='submit' type='submit' value='Checkout' >
</form>
